# Thulasi Dharan S — Professional Portfolio

A simple, responsive portfolio website built with HTML and CSS.

## Included sections
- About Me
- Education
- Internship Experience
- Skills
- Projects
- Contact and LinkedIn

## Publish with GitHub Pages (free)
1. Create a GitHub repository named `thulasi-portfolio`.
2. Upload `index.html` and `README.md` from this folder.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then save.
6. Wait a few minutes. GitHub will show the published website link in the Pages section.

## Before publishing
- Check the education/college name spelling against your official documents.
- Confirm the CSR internship dates and descriptions.
- Add real project files/screenshots only after completing the projects.
- Add a resume PDF only if you are comfortable making it publicly accessible.
- Do not publish your phone number or personal email unless you want them public.
